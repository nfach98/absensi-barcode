

<?php $__env->startSection('app'); ?>
<main>
	<div>
	    <div class="row">
	        <div class="col-12">
	            <div class="card mb-4 mx-4">
	                <div class="card-header pb-0">
	                    <div class="d-flex flex-row justify-content-between">
	                        <div>
	                            <h5 class="mb-0">Data Pegawai</h5>
	                        </div>
	                        <a href="#" class="btn bg-gradient-primary btn-sm mb-0" type="date"><?php $tgl=date('l, d-m-Y'); echo $tgl; ?></a>
	                    </div>
	                </div>
	                <div class="card-body px-0 pt-0 pb-2">
	                    <div class="table-responsive p-0">
	                        <table class="table align-items-center mb-0">
	                            <thead>
	                                <tr>
	                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
	                                        Pegawai
	                                    </th>
	                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
	                                        Email
	                                    </th>
	                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
	                                        Jabatan
	                                    </th>
	                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
	                                        No. Telp
	                                    </th>
	                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
	                                        Jam Masuk
	                                    </th>
	                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
	                                        Suhu Badan
	                                    </th>
	                                </tr>
	                            </thead>
	                            <tbody>
	                            	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<tr>
	                                    <td class="text-center">
	                                    	<div class="d-flex flex-row justify-content-center align-items-center">
	                                            <img src="<?php echo e($user->foto ? url($user->foto) : url('assets\img\placeholder_avatar.png')); ?>" class="avatar avatar-sm me-3">
	                                        	<p class="text-xs font-weight-bold mb-0"><?php echo e($user->name); ?></p>
	                                    	</div>
	                                    </td>
	                                    <td class="text-center">
	                                        <p class="text-xs font-weight-bold mb-0"><?php echo e($user->email); ?></p>
	                                    </td>
	                                    <td class="text-center">
	                                        <p class="text-xs font-weight-bold mb-0"><?php echo e($user->jabatan); ?></p>
	                                    </td>
	                                    <td class="text-center">
	                                        <span class="text-secondary text-xs font-weight-bold"><?php echo e($user->phone); ?></span>
	                                    </td>
	                                     <td class="text-center">
	                                        <span class="text-secondary text-xs font-weight-bold"><?php echo e($user->jam_masuk); ?></span>
	                                    </td>
	                                     <td class="text-center">
	                                        <span class="text-secondary text-xs font-weight-bold"><?php echo e($user->suhu_badan); ?> °C</span>
	                                    </td>
	                                    
	                                </tr>
	                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                            </tbody>
	                        </table>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	</div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Makaryo\2021\absensi-app\web\resources\views/management.blade.php ENDPATH**/ ?>