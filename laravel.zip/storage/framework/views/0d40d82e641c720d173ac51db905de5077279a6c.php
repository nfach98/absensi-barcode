<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-content position-relative bg-gray-100">
    <?php echo $__env->make('layouts.navbars.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
        <div class="container-fluid">
            <?php echo $__env->yieldContent('app'); ?>
            
        </div>
    </main>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Makaryo\2021\absensi-app\web\resources\views/layouts/app.blade.php ENDPATH**/ ?>